    </div>
    <footer style="text-align: center; padding: 20px; color: #666; font-size: 12px;">
        &copy; <?php echo date('Y'); ?> School Management System. All rights reserved.
    </footer>
</body>
</html>
