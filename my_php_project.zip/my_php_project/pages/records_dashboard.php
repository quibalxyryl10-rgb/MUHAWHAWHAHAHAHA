<?php
require_once __DIR__ . '/../includes/auth.php';

$records_msg = "";
$r_view_stud = null; $r_transcript = null;

if (isset($_SESSION['role']) && $_SESSION['role'] == 'records') {
    if (isset($_POST['r_search_btn'])) {
        $term = $conn->real_escape_string($_POST['search_term']);
        $r_results = $conn->query("SELECT * FROM users WHERE role_id=2 AND is_approved=1 AND (first_name LIKE '%$term%' OR last_name LIKE '%$term%' OR username LIKE '%$term%')");
    }
    if (isset($_GET['view_stud'])) {
        $sid = intval($_GET['view_stud']);
        $r_view_stud = $conn->query("SELECT * FROM users WHERE id=$sid")->fetch_assoc();
        // Get all subjects taken regardless of SY and sem
        $r_transcript = $conn->query("SELECT ss.*, s.code, s.name as subject_name, s.units, sy.name as sy_name, sem.name as sem_name, g.grade_1st, g.grade_2nd, g.grade_3rd, g.grade_final, g.remarks 
            FROM student_subjects ss 
            JOIN subjects s ON ss.subject_id = s.id 
            JOIN school_years sy ON ss.sy_id = sy.id 
            JOIN semesters sem ON ss.sem_id = sem.id 
            LEFT JOIN grades g ON g.student_subject_id = ss.id 
            WHERE ss.student_id = $sid AND ss.status = 'Enrolled'
            ORDER BY sy.name DESC, sem.id DESC, s.code ASC");
    }
    if (isset($_POST['edit_student_btn'])) {
        $sid = intval($_POST['edit_sid']);
        $conn->query("UPDATE users SET first_name='".$conn->real_escape_string($_POST['first_name'])."', middle_name='".$conn->real_escape_string($_POST['middle_name'])."', last_name='".$conn->real_escape_string($_POST['last_name'])."', birthdate='".$conn->real_escape_string($_POST['birthdate'])."' WHERE id=$sid");
        $records_msg = "<div class='success'>Student info updated.</div>";
    }
    if (isset($_POST['edit_grade_btn'])) {
        $ssid = intval($_POST['edit_ssid']);
        $g1 = floatval($_POST['grade_1st']);
        $g2 = floatval($_POST['grade_2nd']);
        $g3 = floatval($_POST['grade_3rd']);
        $gf = floatval($_POST['grade_final']);
        $rem = $conn->real_escape_string($_POST['remarks']);
        $chk = $conn->query("SELECT id FROM grades WHERE student_subject_id=$ssid");
        if($chk->num_rows > 0) {
            $conn->query("UPDATE grades SET grade_1st=$g1, grade_2nd=$g2, grade_3rd=$g3, grade_final=$gf, remarks='$rem' WHERE student_subject_id=$ssid");
        } else {
            $conn->query("INSERT INTO grades (student_subject_id, grade_1st, grade_2nd, grade_3rd, grade_final, remarks) VALUES ($ssid, $g1, $g2, $g3, $gf, '$rem')");
        }
        $records_msg = "<div class='success'>Grade updated.</div>";
    }
}

$name = $_SESSION['name']; $role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Management System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        @media print {
            .no-print { display: none !important; }
            .header-links, .btn { display: none !important; }
            body { background: white; }
            .card { box-shadow: none; border: 1px solid #ddd; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>School Management System</h2>
        <div class="header-links">
            <a href="?action=profile">⚙️ Profile</a>
            <a href="?action=logout">Logout</a>
        </div>
    </div>
    <div class="dashboard-container">
        <?php echo $records_msg; ?>
        <h2>Welcome, <?php echo htmlspecialchars($name); ?>! <span class="role-badge">Records</span></h2>

        <?php if (!isset($_GET['view_stud'])): ?>
        <div class="card">
            <h3>Search Student</h3>
            <form method="POST" class="form-row" style="max-width:500px;">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <div class="form-group" style="flex:2;"><input type="text" name="search_term" placeholder="Search by name or username..." required></div>
                <div class="form-group"><button type="submit" name="r_search_btn" class="btn">Search</button></div>
            </form>
        </div>

        <?php if(isset($r_results) && $r_results->num_rows > 0): ?>
        <div class="card">
            <h3>Search Results</h3>
            <table>
                <tr><th>Name</th><th>Username</th><th>Course</th><th>Action</th></tr>
                <?php while($r=$r_results->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($r['first_name'].' '.$r['last_name']); ?></td>
                    <td><?php echo htmlspecialchars($r['username']); ?></td>
                    <td><?php echo htmlspecialchars($r['course']); ?></td>
                    <td><a href="?action=records&view_stud=<?php echo $r['id']; ?>" class="btn btn-sm btn-success">View TOR</a></td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
        <?php endif; ?>

        <?php else: ?>
        <button onclick="window.location.href='?action=records'" class="btn btn-sm no-print" style="margin-bottom:15px;">&larr; Back to Search</button>

        <?php if($r_view_stud): ?>
        <div class="card">
            <div class="form-row" style="justify-content:space-between; align-items:center;">
                <div>
                    <h3 style="border:none; margin:0;">Transcript of Records</h3>
                    <p style="color:#666;">
                        <strong>Name:</strong> <?php echo htmlspecialchars($r_view_stud['first_name'].' '.$r_view_stud['middle_name'].' '.$r_view_stud['last_name'].($r_view_stud['suffix']?', '.$r_view_stud['suffix']:'')); ?><br>
                        <strong>Course:</strong> <?php echo $r_view_stud['course']; ?> | <strong>Year Level:</strong> <?php echo $r_view_stud['year_level']; ?>
                    </p>
                </div>
                <button onclick="window.print()" class="btn btn-primary no-print">Print TOR</button>
            </div>
        </div>

        <div class="card">
            <h4>All Subjects Taken</h4>
            <?php if($r_transcript && $r_transcript->num_rows > 0): ?>
            <table>
                <tr><th>SY</th><th>Sem</th><th>Code</th><th>Subject</th><th>Units</th><th>1st</th><th>2nd</th><th>3rd</th><th>Final</th><th>Remarks</th><th class="no-print">Action</th></tr>
                <?php while($t=$r_transcript->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $t['sy_name']; ?></td>
                    <td><?php echo $t['sem_name']; ?></td>
                    <td><?php echo $t['code']; ?></td>
                    <td><?php echo $t['subject_name']; ?></td>
                    <td style="text-align:center;"><?php echo $t['units']; ?></td>
                    <td style="text-align:center;"><?php echo $t['grade_1st'] ?? '-'; ?></td>
                    <td style="text-align:center;"><?php echo $t['grade_2nd'] ?? '-'; ?></td>
                    <td style="text-align:center;"><?php echo $t['grade_3rd'] ?? '-'; ?></td>
                    <td style="text-align:center;"><?php echo $t['grade_final'] ?? '-'; ?></td>
                    <td><?php echo htmlspecialchars($t['remarks'] ?? '-'); ?></td>
                    <td class="no-print">
                        <form method="POST" style="margin:0;">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                            <input type="hidden" name="edit_ssid" value="<?php echo $t['id']; ?>">
                            <button type="submit" name="edit_grade_btn" class="btn btn-sm btn-warning">Edit Grade</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table>
            <?php else: echo "<small>No subjects found.</small>"; endif; ?>
        </div>

        <div class="card no-print">
            <h4>Edit Student Information</h4>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="edit_sid" value="<?php echo $r_view_stud['id']; ?>">
                <div class="form-row">
                    <div class="form-group"><label>First Name</label><input type="text" name="first_name" value="<?php echo $r_view_stud['first_name']; ?>" required></div>
                    <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name" value="<?php echo $r_view_stud['middle_name']; ?>"></div>
                    <div class="form-group"><label>Last Name</label><input type="text" name="last_name" value="<?php echo $r_view_stud['last_name']; ?>" required></div>
                </div>
                <div class="form-group"><label>Birthdate</label><input type="date" name="birthdate" value="<?php echo $r_view_stud['birthdate']; ?>" required></div>
                <button type="submit" name="edit_student_btn" class="btn btn-success">Update Info</button>
            </form>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>
