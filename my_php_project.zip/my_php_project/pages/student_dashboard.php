<?php
require_once __DIR__ . '/../includes/auth.php';

// Ensure sys_settings is available
if (!isset($sys_settings) || $sys_settings === null) {
    $sys_settings = ['fee_per_unit' => 500.00, 'misc_fee' => 50.00];
}

$student_msg = "";
if (isset($_SESSION['role']) && $_SESSION['role'] == 'student') {
    if (isset($_POST['add_subject_btn'])) {
        $sid=$_SESSION['user_id']; $subid=intval($_POST['subject_id']); $syid=intval($_POST['sy_id']); $semid=intval($_POST['sem_id']);
        $check=$conn->query("SELECT id FROM student_subjects WHERE student_id=$sid AND subject_id=$subid AND sy_id=$syid AND sem_id=$semid");
        if($check->num_rows==0) {
            $conn->query("INSERT INTO student_subjects (student_id, subject_id, sy_id, sem_id) VALUES ($sid, $subid, $syid, $semid)");
            $sub=$conn->query("SELECT units FROM subjects WHERE id=$subid")->fetch_assoc(); 
            if($sub) {
                $units=$sub['units']; $fee=$sys_settings['fee_per_unit']; $misc=$sys_settings['misc_fee'];
                $acc=$conn->query("SELECT id, total_fees FROM student_accounts WHERE student_id=$sid AND sy_id=$syid AND sem_id=$semid");
                if($acc->num_rows>0) { $acc_data=$acc->fetch_assoc(); $new_total=$acc_data['total_fees']+($units*$fee); $conn->query("UPDATE student_accounts SET total_fees=$new_total, balance=$new_total WHERE id=".$acc_data['id']); }
                else { $new_total=($units*$fee)+$misc; $conn->query("INSERT INTO student_accounts (student_id, sy_id, sem_id, total_fees, balance) VALUES ($sid, $syid, $semid, $new_total, $new_total)"); }
                $student_msg="<div class='success'>Subject added.</div>";
            } else {
                $student_msg="<div class='error'>Subject not found.</div>";
            }
        } else $student_msg="<div class='error'>Already enrolled.</div>";
    }
    if (isset($_POST['drop_subject_btn'])) {
        $ssid=intval($_POST['student_subject_id']); $syid=intval($_POST['sy_id']); $semid=intval($_POST['sem_id']);
        $ss=$conn->query("SELECT subject_id FROM student_subjects WHERE id=$ssid")->fetch_assoc(); 
        if($ss) {
            $subid=$ss['subject_id'];
            $sub=$conn->query("SELECT units FROM subjects WHERE id=$subid")->fetch_assoc(); 
            if($sub) {
                $units=$sub['units']; $fee=$sys_settings['fee_per_unit'];
                $conn->query("DELETE FROM student_subjects WHERE id=$ssid");
                $sid=$_SESSION['user_id']; $acc=$conn->query("SELECT id, total_fees FROM student_accounts WHERE student_id=$sid AND sy_id=$syid AND sem_id=$semid")->fetch_assoc();
                if($acc) {
                    $new_total=$acc['total_fees']-($units*$fee); $conn->query("UPDATE student_accounts SET total_fees=$new_total, balance=$new_total WHERE id=".$acc['id']);
                    $student_msg="<div class='success'>Subject dropped.</div>";
                } else {
                    $student_msg="<div class='error'>Account not found.</div>";
                }
            } else {
                $student_msg="<div class='error'>Subject not found.</div>";
            }
        } else {
            $student_msg="<div class='error'>Enrollment not found.</div>";
        }
    }
    if (isset($_POST['enroll_block_btn'])) {
        $sid=$_SESSION['user_id']; $bid=intval($_POST['block_sec_id']); $syid=intval($_POST['sy_id']); $semid=intval($_POST['sem_id']);
        $subs=$conn->query("SELECT subject_id FROM section_subjects WHERE section_id=$bid"); $added=0;
        while($s=$subs->fetch_assoc()) {
            $subid=$s['subject_id']; $check=$conn->query("SELECT id FROM student_subjects WHERE student_id=$sid AND subject_id=$subid AND sy_id=$syid AND sem_id=$semid");
            if($check->num_rows==0) { $conn->query("INSERT INTO student_subjects (student_id, subject_id, sy_id, sem_id) VALUES ($sid, $subid, $syid, $semid)"); $added++; }
        }
        if($added>0) {
            $subs=$conn->query("SELECT s.units FROM student_subjects ss JOIN subjects s ON ss.subject_id=s.id WHERE ss.student_id=$sid AND ss.sy_id=$syid AND ss.sem_id=$semid"); $total_units=0;
            while($s=$subs->fetch_assoc()) $total_units+=$s['units'];
            $fee=$sys_settings['fee_per_unit']; $misc=$sys_settings['misc_fee']; $new_total=($total_units*$fee)+$misc;
            $acc=$conn->query("SELECT id FROM student_accounts WHERE student_id=$sid AND sy_id=$syid AND sem_id=$semid");
            if($acc->num_rows>0) { $acc_data=$acc->fetch_assoc(); $conn->query("UPDATE student_accounts SET total_fees=$new_total, balance=$new_total WHERE id=".$acc_data['id']); }
            else $conn->query("INSERT INTO student_accounts (student_id, sy_id, sem_id, total_fees, balance) VALUES ($sid, $syid, $semid, $new_total, $new_total)");
            $student_msg="<div class='success'>$added subjects enrolled.</div>";
        } else $student_msg="<div class='error'>No new subjects added.</div>";
    }
}

$name = $_SESSION['name']; $role = $_SESSION['role'];
$sd=$conn->query("SELECT course FROM users WHERE id=".$_SESSION['user_id'])->fetch_assoc();
$sm=24; if($sd['course']){ $cm=$conn->query("SELECT max_units FROM courses WHERE code='".$sd['course']."'")->fetch_assoc(); if($cm)$sm=$cm['max_units']; }
$asy=isset($_GET['sy_id'])?$_GET['sy_id']:1; $asem=isset($_GET['sem_id'])?$_GET['sem_id']:1; $csid=$_SESSION['user_id'];

// Ensure sys_settings is available
if (!isset($sys_settings) || $sys_settings === null) {
    $sys_settings = ['fee_per_unit' => 500.00, 'misc_fee' => 50.00];
}

// Recalculate student account if enrolled subjects exist but account is missing or zero
$acc_check = $conn->query("SELECT * FROM student_accounts WHERE student_id=$csid AND sy_id=$asy AND sem_id=$asem");
if ($acc_check->num_rows == 0) {
    $subs_check = $conn->query("SELECT s.units FROM student_subjects ss JOIN subjects s ON ss.subject_id=s.id WHERE ss.student_id=$csid AND ss.sy_id=$asy AND ss.sem_id=$asem AND ss.status='Enrolled'");
    if ($subs_check->num_rows > 0) {
        $total_units = 0;
        while ($s = $subs_check->fetch_assoc()) {
            $total_units += $s['units'];
        }
        $new_total = ($total_units * $sys_settings['fee_per_unit']) + $sys_settings['misc_fee'];
        $conn->query("INSERT INTO student_accounts (student_id, sy_id, sem_id, total_fees, balance) VALUES ($csid, $asy, $asem, $new_total, $new_total)");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Management System</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="header">
        <h2>School Management System</h2>
        <div class="header-links">
            <a href="?action=profile">⚙️ Profile</a>
            <a href="?action=logout">Logout</a>
        </div>
    </div>
    <div class="dashboard-container">
        <?php echo $student_msg; ?>
        <h2>Welcome, <?php echo htmlspecialchars($name); ?>! <span class="role-badge">Student</span></h2>
        <div class="alert-box">⚠️ Max Units: <strong><?php echo $sm; ?></strong> | Fees: <strong>₱<?php echo $sys_settings['fee_per_unit']; ?>/unit + ₱<?php echo $sys_settings['misc_fee']; ?></strong></div>
        <div class="card"><form method="GET" action="" class="form-row" style="align-items: flex-end;">
            <div class="form-group"><label>School Year</label><select name="sy_id" required><?php $sys=$conn->query("SELECT * FROM school_years ORDER BY name DESC"); while($sy=$sys->fetch_assoc()){$sel=(isset($_GET['sy_id'])&&$_GET['sy_id']==$sy['id'])?'selected':''; echo "<option value='".$sy['id']."' $sel>".$sy['name']."</option>";} ?></select></div>
            <div class="form-group"><label>Semester</label><select name="sem_id" required><?php $sems=$conn->query("SELECT * FROM semesters ORDER BY id"); while($sem=$sems->fetch_assoc()){$sel=(isset($_GET['sem_id'])&&$_GET['sem_id']==$sem['id'])?'selected':''; echo "<option value='".$sem['id']."' $sel>".$sem['name']."</option>";} ?></select></div>
            <div class="form-group"><button type="submit" class="btn">View Records</button></div>
        </form></div>

        <div class="student-grid">
            <div class="card">
                <h3>Quick Enrollment</h3>
                <div class="alert-box" style="background:#d4edda;color:#155724;border-color:#c3e6cb;">🚀 Enroll in a Block Section to add multiple subjects instantly!</div>
                <form method="POST" class="form-row" style="margin-bottom:20px;">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="sy_id" value="<?php echo $asy; ?>"><input type="hidden" name="sem_id" value="<?php echo $asem; ?>">
                    <div class="form-group"><label>Block Section</label><select name="block_sec_id" required><option value="">Select Section...</option><?php $bsecs=$conn->query("SELECT * FROM sections WHERE course_code='".$sd['course']."' AND sy_id=$asy AND sem_id=$asem"); while($bs=$bsecs->fetch_assoc()) echo "<option value='".$bs['id']."'>".$bs['name']."</option>"; ?></select></div>
                    <div class="form-group" style="align-self:flex-end;"><button type="submit" name="enroll_block_btn" class="btn btn-success">Enroll in Block</button></div>
                </form>
                <h3>Or Add Subject Individually</h3>
                <form method="POST" action=""><input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>"><input type="hidden" name="sy_id" value="<?php echo $asy; ?>"><input type="hidden" name="sem_id" value="<?php echo $asem; ?>"><div class="form-row"><div class="form-group" style="flex: 2;"><select name="subject_id" required><option value="">Select Subject...</option><?php $av=$conn->query("SELECT * FROM subjects ORDER BY code"); while($s=$av->fetch_assoc()) echo "<option value='".$s['id']."'>".$s['code']." - ".$s['name']." (".$s['units']." u)</option>"; ?></select></div><div class="form-group" style="flex: 1;"><button type="submit" name="add_subject_btn" class="btn" style="width:100%;">Add Subject</button></div></div></form>
            </div>

            <div class="card">
                <h3>📅 My Class Schedule</h3>
                <?php $sched=$conn->query("SELECT ta.schedule, ta.room, s.code, s.name, CONCAT(u.last_name, ', ', u.first_name) as teacher FROM student_subjects ss JOIN teacher_assignments ta ON ss.subject_id=ta.subject_id AND ss.sy_id=ta.sy_id AND ss.sem_id=ta.sem_id JOIN subjects s ON ta.subject_id=s.id JOIN users u ON ta.teacher_id=u.id WHERE ss.student_id=$csid AND ss.status='Enrolled' AND ss.sy_id=$asy AND ss.sem_id=$asem ORDER BY ta.schedule"); ?>
                <table><tr><th>Schedule</th><th>Subject</th><th>Prof</th><th>Room</th></tr>
                <?php while($sc=$sched->fetch_assoc()): ?>
                <tr><td style="font-weight:bold;"><?php echo htmlspecialchars($sc['schedule']); ?></td><td><?php echo $sc['code']; ?></td><td><?php echo htmlspecialchars($sc['teacher']); ?></td><td><?php echo htmlspecialchars($sc['room']); ?></td></tr>
                <?php endwhile; if($sched->num_rows==0) echo "<tr><td colspan='4' style='text-align:center'>No schedule found.</td></tr>"; ?>
                </table>
            </div>
        </div>

        <div class="card"><h3>Enrolled Subjects</h3><table><thead><tr><th>Code</th><th>Subject Name</th><th>Units</th><th>Status</th><th>Action</th></tr></thead><tbody>
            <?php $mys=$conn->query("SELECT ss.id as ss_id, s.code, s.name, s.units, ss.status FROM student_subjects ss JOIN subjects s ON ss.subject_id = s.id WHERE ss.student_id = $csid AND ss.sy_id = $asy AND ss.sem_id = $asem"); $tu=0;
            if($mys->num_rows > 0) { while($r=$mys->fetch_assoc()) { if($r['status']=='Enrolled') $tu+=$r['units']; echo "<tr><td>".$r['code']."</td><td>".$r['name']."</td><td>".$r['units']."</td><td><span class='role-badge' style='font-size:12px;'>".$r['status']."</span></td><td>"; if($r['status']=='Enrolled') echo "<form method='POST' action='' style='margin:0;'><input type='hidden' name='csrf_token' value='".$csrf_token."'><input type='hidden' name='student_subject_id' value='".$r['ss_id']."'><input type='hidden' name='sy_id' value='".$asy."'><input type='hidden' name='sem_id' value='".$asem."'><button type='submit' name='drop_subject_btn' class='btn btn-danger btn-sm'>Drop</button></form>"; else echo "-"; echo "</td></tr>"; } } else echo "<tr><td colspan='5' style='text-align:center;'>No subjects enrolled.</td></tr>"; ?>
        </tbody></table>
            <?php $col=($tu>$sm)?'color:red;':'color: var(--primary-blue);'; echo "<div style='margin-top: 15px; font-weight: bold; $col'>Total Units: $tu / $sm</div>"; ?>
        </div>

        <div class="student-grid">
            <div class="card"><h3>Accounts & Billing</h3>
                <?php $acc=$conn->query("SELECT * FROM student_accounts WHERE student_id=$csid AND sy_id=$asy AND sem_id=$asem");
                if($acc->num_rows>0){ $ad=$acc->fetch_assoc(); echo "<table><tr><td><strong>Total Fees:</strong></td><td style='text-align:right;'>₱ ".number_format($ad['total_fees'],2)."</td></tr><tr><td><strong>Paid:</strong></td><td style='text-align:right;color:green;'>₱ ".number_format($ad['amount_paid'],2)."</td></tr><tr><td><strong>Balance:</strong></td><td style='text-align:right;color:red;font-weight:bold;'>₱ ".number_format($ad['balance'],2)."</td></tr></table><div class='permit-box ".strtolower($ad['permit_status'])."'><h3>Exam Permit</h3><p style='font-size:24px;font-weight:bold;margin:10px 0;'>".$ad['permit_status']."</p>".($ad['permit_status']=='Pending'?"<p style='font-size:12px;'>Settle balance at cashier.</p>":"<p style='font-size:12px;'>Cleared.</p>")."</div>"; } else echo "<p>No billing records.</p>"; ?>
            </div>
        </div>
    </div>
</body>
</html>
